package com.bangkit.onikku.data.model

data class FaqModel(
    val id: Int,
    val titleFaq: String,
    val descFaq: String,
)
